﻿class program
{
    static void Main(string[] args)
    {
        JuegoDeDados j = new JuegoDeDados();
        j.Jugar();
    }
}