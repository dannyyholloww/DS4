﻿using System;

namespace Laboratorio_12.1
{
    internal class Calculo
    {
        public double CalcularDistancia(double velocidad, double tiempo)
        {
            return velocidad * tiempo;
        }
    }
}