﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_12.2
{
    internal class CalcularPromedio
    {
        public double CalcularPromedioTotal(double uno, double dos, double tres)
        {
            return (uno + dos + tres) / 3;
        }
    }
}